package pojo;

import lombok.Data;

@Data
public class BookingDates {

    private String checkin;
    private String checkout;
}
