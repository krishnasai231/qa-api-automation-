package testClasses;

import org.testng.annotations.Test;

public class ApiTests {


    @Test
    public void testGetAllBookingsApi() {

    }
}